package com.example.urms_ulab

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
